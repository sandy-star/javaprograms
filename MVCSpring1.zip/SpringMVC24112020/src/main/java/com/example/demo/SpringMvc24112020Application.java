package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvc24112020Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvc24112020Application.class, args);
	}

}
