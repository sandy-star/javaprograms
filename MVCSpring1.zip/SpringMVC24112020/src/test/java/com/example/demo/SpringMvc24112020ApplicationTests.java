package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvc24112020ApplicationTests {

	@Test
	void contextLoads() {
	}

}
