package com.example.demo.service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.example.demo.dao.PersonDao;
import com.example.demo.exception.PersonIdNotFoundException;
import com.example.demo.model.Person;

@Service
public class PersonService {
	
	@Autowired
	private PersonDao dao;

	public List<Person> getAllPersons() {
		
		return dao.findAll();
	}

	public Person postPersons(Person per) {		
		return dao.save(per);
	}

	public void deletePersonById(Integer id) throws PersonIdNotFoundException {
		// TODO Auto-generated method stub
		Optional<Person> p = dao.findById(id);
		if(p.isPresent()) {
			dao.deleteById(id);
		} else {
			throw new PersonIdNotFoundException("Person id "+id+" Not Found");
		}
		
	}

	public Person updatePerson(Person person, Integer id) {
		Optional<Person> p = dao.findById(id);
		Person per = null ;
		if(p.isPresent()) {
			Person pp = p.get();
			pp.setpId(id);
            pp.setFirstName(person.getFirstName());
            pp.setLastName(person.getLastName());
          per =  dao.save(pp);
		}else {
			per = new Person();
			per.setFirstName(person.getFirstName());
			per.setLastName(person.getLastName());
			per.setpId(id);
			dao.save(per);
		}
		return per;
		
	
	}
	
	
}
