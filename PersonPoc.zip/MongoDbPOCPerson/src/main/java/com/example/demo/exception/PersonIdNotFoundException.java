package com.example.demo.exception;

public class PersonIdNotFoundException extends Exception {

	public PersonIdNotFoundException(String string) {
		super(string);
	}

}
