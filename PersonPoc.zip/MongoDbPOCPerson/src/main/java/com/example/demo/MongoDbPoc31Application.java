package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongoDbPoc31Application {

	public static void main(String[] args) {
		SpringApplication.run(MongoDbPoc31Application.class, args);
		System.out.println("HII SUYASH");
	}

}
