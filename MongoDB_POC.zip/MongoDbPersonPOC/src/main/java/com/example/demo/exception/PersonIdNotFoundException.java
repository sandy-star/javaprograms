package com.example.demo.exception;

public class PersonIdNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PersonIdNotFoundException(String string) {
		super(string);
	}

}
